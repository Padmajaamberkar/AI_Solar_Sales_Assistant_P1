
from groq import Groq

client = Groq(api_key="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")

def ask_ai(question):

    prompt = f"""
    You are an expert Solar Energy Consultant.

    Answer the customer's question professionally.

    Question:
    {question}
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role":"user",
                "content":prompt
            }
        ]
    )

    return response.choices[0].message.content
